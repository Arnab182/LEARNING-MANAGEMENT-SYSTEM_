var express = require('express');
var router = express.Router();
var dbConn  = require('../lib/db');
 
router.get('/', function(req, res, next) {      
    
    res.render('users/index');   
        
});

module.exports = router;