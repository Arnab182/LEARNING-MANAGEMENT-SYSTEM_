var express = require('express');
var router = express.Router();
var dbConn  = require('../lib/db');
var multer=require('multer');
var fileUpload=require('express-fileupload');

router.get('/', function(req, res, next) {      
    
    if(!req.session.adm)
    {
        res.render('admin/index',{msg:""}); 
    }  
    else
    {
        res.redirect('/admin/profile');
    }
});
router.post('/', function(req, res, next) {   
    let adminid = req.body.adminid.trim();
    let password = req.body.password.trim(); 

    let q4="SELECT count(*) as count2 FROM admin where `adminid`='"+adminid+"' and `password`='"+password+"'";
    dbConn.query(q4,function(err,result4){
    //queries string
    if(result4[0].count2>0)
    {
        req.session.adm=adminid;
        res.redirect('/admin/profile');
        
    }
    else
    {
        console.log(result4);
        res.render('admin/index',{msg:"invalid login details"});   
    }
});
});
router.get('/profile', function(req, res, next) {  
    if(!req.session.adm)
    {
        res.redirect('/admin');
    }  
    else
    {
    // render to add.ejs
    let q1="SELECT * FROM student ORDER BY id desc";
    dbConn.query(q1,function(err,result){
        if(err) {
            req.flash('error', err);
            // render to views/users/index.ejs
            res.render('admin/profile',{data:''});   
        } else {
            // render to views/users/index.ejs
            nm=req.session.adm;
            res.render('admin/profile',{data:result,nm:nm});
        }
    });
    }
});
router.get('/add_student', function(req, res, next) {  
    if(!req.session.adm)
    {
        res.redirect('/admin');
    }  
    else
    {
    // render to add.ejs
    
            nm=req.session.adm;
            res.render('admin/addstudent',{nm:nm});
    }
});
router.post('/store_student', function(req, res, next) {  
    //upload
    var timestamp = new Date().toISOString().replace(/[-:.]/g,"");  
    var random = ("" + Math.random()).substring(2, 8); 
    var random_number = timestamp+random; 

    var storage = multer.diskStorage({
        destination: function (req, file, cb) {
          cb(null, './public/images/student/')
        },
        filename: function (req, file, cb) {
          cb(null, random_number+'.jpg')
        }
      });
      var upload = multer({ storage: storage }).single('image');
      upload(req,res,function(err){
          if(err)
          {
           
          }
          else
          {
          //Receive Data
          let image=random_number+".jpg";
    let name = req.body.name;
    let email = req.body.email;
    let phone = req.body.phone;
    let password = req.body.password;
    let gender = req.body.gender;
    let nationality = req.body.nationality;

    

    //store into dictionary
    var form_data = {
        image:image,
        name: name,
        email: email,
        phone:phone,
        password:password,
        gender:gender,
        nationality:nationality,
    }
    //queries string
    let q1="insert into `student` set ?";
    //execution
    dbConn.query(q1, form_data, function(err, result) {
        if (err) {
            req.flash('error', err)
            res.render('admin/add_student')
        }
        else{
            req.flash('success', 'Student successfully added');
            res.redirect('/admin/profile');    
        }
    });
          }
        });
    
});
router.get('/edit/(:y)', function(req, res, next) {   
    // render to add.ejs
    let y = req.params.y;
    let q1="SELECT * FROM student where `id`="+y;
    dbConn.query(q1,function(err,result){
        if(err) {
            req.flash('error', err);
            // render to views/users/index.ejs
            
            res.render('users/edit',{
                id: '',
                name: '',
                email: '',
                phone: '',
                password: '',
                gender: '',
                nationality: '',
            });   
        } else {
            // render to views/users/index.ejs
            res.render('admin/edit',{
                id: result[0].id,
                name: result[0].name,
                email: result[0].email,
                phone: result[0].phone,
                password: result[0].password,
                gender: result[0].gender,
                nationality: result[0].nationality,});
        }
    });
    
});
router.post('/update_student', function(req, res, next) {  
    //upload
    let id = req.body.id;
    let name = req.body.name;
    let email = req.body.email;
    let phone = req.body.phone;
    let password = req.body.password;
    let gender = req.body.gender;
    let nationality = req.body.nationality;

    

    //store into dictionary
    var form_data = {
        name: name,
        email: email,
        phone:phone,
        password:password,
        gender:gender,
        nationality:nationality,
    }
    //queries string
    let q1="update `student` set ? where `id`='"+id+"'";
    //execution
    dbConn.query(q1, form_data, function(err, result) {
        if (err) {
            req.flash('error', err)
            res.render('admin/edit')
        }
        else{
            req.flash('success', 'Student successfully updated');
            res.redirect('/admin/profile');    
        }
    });
    
});

router.get('/edit_img/(:y)', function(req, res, next) {   
    // render to add.ejs
    let y = req.params.y;
    let q1="SELECT * FROM student where `id`="+y;
    dbConn.query(q1,function(err,result){
        if(err) {
            req.flash('error', err);
            // render to views/users/index.ejs
            
            res.render('users/edit_img',{
                id: '',
               image: '',
            });   
        } else {
            // render to views/users/index.ejs
            res.render('admin/edit_img',{
                id: result[0].id,
                image: result[0].image,});
        }
    });
    
});
router.post('/update_img', function(req, res, next) {  
    //upload
    var timestamp = new Date().toISOString().replace(/[-:.]/g,"");  
    var random = ("" + Math.random()).substring(2, 8); 
    var random_number = timestamp+random; 

    var storage = multer.diskStorage({
        destination: function (req, file, cb) {
          cb(null, './public/images/student/')
        },
        filename: function (req, file, cb) {
          cb(null, random_number+'.jpg')
        }
      });
      var upload = multer({ storage: storage }).single('image');
      upload(req,res,function(err){
          if(err)
          {
           
          }
          else
          {
          //Receive Data
          let image=random_number+".jpg";
    let id = req.body.id;   

    //store into dictionary
    var form_data = {
        image:image,
    }
    //queries string
    let q1="update `student` set ? where `id`='"+id+"'";
    //execution
    dbConn.query(q1, form_data, function(err, result) {
        if (err) {
            req.flash('error', err)
            res.render('admin/edit_img')
        }
        else{
            req.flash('success', 'Student successfully updated');
            res.redirect('/admin/profile');    
        }
    });
          }
        });
    
});
router.get('/delete/(:y)', function(req, res, next) {   
    // render to add.ejs
    let y = req.params.y;
    let q1="SELECT * FROM student where `id`="+y;
    dbConn.query(q1,function(err,result){
        if(err) {
            req.flash('error', err);
            // render to views/users/index.ejs
            
            res.render('users/edit',{
                id: '',
                name: '',
                email: '',
                phone: '',
                password: '',
                gender: '',
                nationality: '',
            });   
        } else {
            let q2="delete FROM student where `id`="+y;
    dbConn.query(q2,function(err,result){
        res.redirect('/admin/profile'); 
    });
        }
    });
    
});


/**************course********** */

router.get('/all_course', function(req, res, next) {    
    if(!req.session.adm)
    {
        res.redirect('/users/');
    }  
    else
    {
    // render to add.ejs
    let q1="SELECT * FROM course ORDER BY id desc";
    dbConn.query(q1,function(err,result){
        if(err) {
            req.flash('error', err);
            // render to views/users/index.ejs
            res.render('admin/all_course',{data:''});   
        } else {
            // render to views/users/index.ejs
            res.render('admin/all_course',{data:result});
        }
    });
}
})
router.get('/add_course', function(req, res, next) {  
    if(!req.session.adm)
    {
        res.redirect('/admin/');
    }  
    else
    {  
    // render to add.ejs
    res.render('admin/add_course')
    }
})

router.post('/store_course', function(req, res, next) {  
    //Receive Data
     var timestamp = new Date().toISOString().replace(/[-:.]/g,"");  
    var random = ("" + Math.random()).substring(2, 8); 
    var random_number = timestamp+random; 

    var storage = multer.diskStorage({
        destination: function (req, file, cb) {
          cb(null, './public/images/courses')
        },
        filename: function (req, file, cb) {
          cb(null, random_number+'.jpg')
        }
      });
      var upload = multer({ storage: storage }).single('image');
      upload(req,res,function(err){
          if(err)
          {
           
          }
          else
          {
          //Receive Data
          let image=random_number+".jpg";
    let name = req.body.name;
    let tfee = req.body.tfee;
    let dfee = req.body.dfee;
    let duration = req.body.duration;
    let details = req.body.details;    
    //store into dictionary
    var form_data = {
        image:image,
        name: name,
        tfee: tfee,
        dfee:dfee,
        duration:duration,
        details:details,
    }
    //queries string
    let q1="insert into `course` set ?";
    //execution
    dbConn.query(q1, form_data, function(err, result) {
        if (err) {
            req.flash('error', err)
            res.render('admin/add_course')
        }
        else{
            req.flash('success', 'course successfully added');
            res.redirect('/admin/all_course');    
        }
    });
}});
})
router.get('/logout', function(req, res, next) {    
    // render to add.ejs
    if(!req.session.adm)
    {
        res.redirect('/admin');
    }  
    else
    {
        req.session.destroy();
        res.redirect('/admin');
        //res.render('admin/index',{msg:"sucessfully logout"});
    }
})
module.exports = router;